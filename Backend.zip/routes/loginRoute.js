let express = require('express');
const router = express.Router();

// app.get("/",(req, res)=>{
//     res.send("Welcome to AdPro API");
// });

module.exports = router;